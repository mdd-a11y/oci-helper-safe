package com.yohann.ocihelper.config.auth;

import jakarta.annotation.Resource;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.*;

/**
 * @author: Yohann
 * @date: 2024/3/30 15:28
 */
@Configuration
public class CrossDomainFilter implements WebMvcConfigurer {

    @Resource
    private AuthInterceptor authInterceptor;

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(authInterceptor)
                .addPathPatterns("/**");
    }

    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**")
                .allowedOrigins("*")
                .allowedMethods("GET", "POST", "OPTIONS")
                .allowedHeaders("*")
                .allowCredentials(false)
                .maxAge(3600)
                .exposedHeaders("Upgrade", "Connection", "Content-Disposition");
    }

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        // Register the hashed Vite assets explicitly before the SPA catch-all.
        // Without these dedicated mappings, a missing static resource can fall through
        // to the SPA error handler and return index.html with a 200 response, which makes
        // browsers try to execute HTML as JavaScript and results in a blank page.
        registry.addResourceHandler("/js/**")
                .addResourceLocations("classpath:/dist/js/");
        registry.addResourceHandler("/css/**")
                .addResourceLocations("classpath:/dist/css/");
        registry.addResourceHandler("/favicon.ico")
                .addResourceLocations("classpath:/dist/");
        registry.addResourceHandler("/**")
                .addResourceLocations("classpath:/dist/");
    }
}
