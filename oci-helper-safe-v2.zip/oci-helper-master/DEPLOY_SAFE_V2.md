# OCI Helper Safe V2

This build keeps the normal instance creation behavior but adds conservative request pacing.

## Safe-mode defaults
- Minimum interval between creation-task API attempts: 180 seconds
- Random jitter: 0-30 seconds
- 429 / TooManyRequests cooldown: 15 minutes
- Maximum 429 cooldown: 30 minutes
- No daily creation-count limit
- Restored tasks use randomized staggered startup delays

## Docker deployment

Build:
```bash
docker build -t oci-helper-safe:v2 .
```

Run (persistent SQLite database and PEM keys):
```bash
docker rm -f oci-helper-safe 2>/dev/null || true
docker volume create oci-helper-data >/dev/null
docker run -d --name oci-helper-safe --restart unless-stopped \
  -p 8088:8818 \
  -v oci-helper-data:/app/oci-helper/data \
  oci-helper-safe:v2
```

The application uses `/app/oci-helper/data/oci-helper.db` for SQLite and `/app/oci-helper/data/keys` for uploaded PEM files.
