package com.yohann.ocihelper.task;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Conservative pacing for OCI instance-creation tasks.
 *
 * This is intentionally a frequency limiter, not a daily creation quota: a task can
 * continue retrying when capacity is unavailable, but repeated API calls are spaced
 * out and 429 responses trigger a cooldown.
 */
@Slf4j
@Component
public class OciRequestSafetyGuard {

    private static final ConcurrentHashMap<String, Long> NEXT_ALLOWED = new ConcurrentHashMap<>();
    private static final ConcurrentHashMap<String, Long> COOLDOWN_UNTIL = new ConcurrentHashMap<>();

    private static boolean enabled;
    private static long minIntervalSeconds;
    private static long jitterSeconds;
    private static long cooldown429Seconds;
    private static long maxCooldownSeconds;

    @Value("${oci-cfg.safety-mode.enabled:true}")
    public void setEnabled(boolean value) { enabled = value; }

    @Value("${oci-cfg.safety-mode.min-interval-seconds:180}")
    public void setMinIntervalSeconds(long value) { minIntervalSeconds = Math.max(0, value); }

    @Value("${oci-cfg.safety-mode.jitter-seconds:30}")
    public void setJitterSeconds(long value) { jitterSeconds = Math.max(0, value); }

    @Value("${oci-cfg.safety-mode.cooldown-429-seconds:900}")
    public void setCooldown429Seconds(long value) { cooldown429Seconds = Math.max(60, value); }

    @Value("${oci-cfg.safety-mode.max-cooldown-seconds:1800}")
    public void setMaxCooldownSeconds(long value) { maxCooldownSeconds = Math.max(cooldown429Seconds, value); }

    public static boolean tryAcquire(String taskId) {
        if (!enabled || taskId == null) {
            return true;
        }
        long now = System.currentTimeMillis();
        long cooldown = COOLDOWN_UNTIL.getOrDefault(taskId, 0L);
        long next = NEXT_ALLOWED.getOrDefault(taskId, 0L);
        long waitUntil = Math.max(cooldown, next);
        if (waitUntil > now) {
            return false;
        }
        long jitter = jitterSeconds == 0 ? 0 : ThreadLocalRandom.current().nextLong(jitterSeconds + 1);
        NEXT_ALLOWED.put(taskId, now + (minIntervalSeconds + jitter) * 1000L);
        return true;
    }

    public static void onTooManyRequests(String taskId) {
        if (!enabled || taskId == null) {
            return;
        }
        long now = System.currentTimeMillis();
        long existing = COOLDOWN_UNTIL.getOrDefault(taskId, 0L);
        long currentRemaining = Math.max(0, (existing - now) / 1000L);
        long nextCooldown = Math.min(maxCooldownSeconds, Math.max(cooldown429Seconds, currentRemaining * 2));
        COOLDOWN_UNTIL.put(taskId, now + nextCooldown * 1000L);
        log.warn("【安全模式】任务 [{}] 收到 OCI 请求频繁信号，进入 {} 秒冷却", taskId, nextCooldown);
    }

    public static void clear(String taskId) {
        if (taskId != null) {
            NEXT_ALLOWED.remove(taskId);
            COOLDOWN_UNTIL.remove(taskId);
        }
    }
}
