package com.yohann.ocihelper.safety;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Conservative pacing for instance-creation requests.
 *
 * This does not impose a daily request quota. It only spaces requests for the
 * same OCI configuration and applies a temporary cooldown after a 429 response.
 * Values can be adjusted with JVM system properties:
 *   -Doci.helper.safe.minIntervalSeconds=120
 *   -Doci.helper.safe.jitterSeconds=30
 *   -Doci.helper.safe.cooldownSeconds=900
 */
public final class OciSafetyGuard {
    private static final long MIN_INTERVAL_SECONDS = Math.max(30L,
            Long.getLong("oci.helper.safe.minIntervalSeconds", 120L));
    private static final long JITTER_SECONDS = Math.max(0L,
            Long.getLong("oci.helper.safe.jitterSeconds", 30L));
    private static final long COOLDOWN_SECONDS = Math.max(60L,
            Long.getLong("oci.helper.safe.cooldownSeconds", 900L));

    private static final ConcurrentHashMap<String, Long> NEXT_ALLOWED = new ConcurrentHashMap<>();

    private OciSafetyGuard() {}

    /** Wait until the next creation request for this OCI config is allowed. */
    public static void await(String key) {
        if (key == null || key.isBlank()) {
            return;
        }
        while (true) {
            long now = System.currentTimeMillis();
            long next = NEXT_ALLOWED.getOrDefault(key, 0L);
            long waitMillis = next - now;
            if (waitMillis <= 0L) {
                long jitter = JITTER_SECONDS == 0 ? 0
                        : ThreadLocalRandom.current().nextLong(JITTER_SECONDS + 1) * 1000L;
                long newNext = now + MIN_INTERVAL_SECONDS * 1000L + jitter;
                if (NEXT_ALLOWED.replace(key, next, newNext)
                        || (next == 0L && NEXT_ALLOWED.putIfAbsent(key, newNext) == null)) {
                    return;
                }
            } else {
                try {
                    Thread.sleep(Math.min(waitMillis, 30_000L));
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    return;
                }
            }
        }
    }

    /** Put this OCI config into a cooldown after a rate-limit response. */
    public static void onTooManyRequests(String key) {
        if (key == null || key.isBlank()) {
            return;
        }
        long cooldownUntil = System.currentTimeMillis() + COOLDOWN_SECONDS * 1000L;
        NEXT_ALLOWED.merge(key, cooldownUntil, Math::max);
    }
}
